document.getElementById('submit-btn').addEventListener('click', function() {
    // Get the values of bedtime and wake-up time
    const bedtime = document.getElementById('bedtime').value;
    const wakeupTime = document.getElementById('wakeup-time').value;

    if (!bedtime || !wakeupTime) {
        alert("Please enter both bedtime and wake-up time.");
        return;
    }

    // Parse the input times into Date objects
    const bedtimeDate = new Date(`1970-01-01T${bedtime}:00`);
    const wakeupTimeDate = new Date(`1970-01-01T${wakeupTime}:00`);

    // Handle the case where the wake-up time is earlier than bedtime (next day)
    if (wakeupTimeDate < bedtimeDate) {
        wakeupTimeDate.setDate(wakeupTimeDate.getDate() + 1); // Add one day
    }

    // Calculate the difference in milliseconds
    const diffInMilliseconds = wakeupTimeDate - bedtimeDate;
    
    // Convert milliseconds to hours and minutes
    const diffInHours = Math.floor(diffInMilliseconds / (1000 * 60 * 60));
    const diffInMinutes = Math.floor((diffInMilliseconds % (1000 * 60 * 60)) / (1000 * 60));

    // Format the sleep duration
    const sleepDuration = `${diffInHours} hours ${diffInMinutes} minutes`;

    // Provide feedback based on the sleep duration
    let feedback = '';
    if (diffInHours >= 7) {
        feedback = "Great job! You're getting enough rest.";
    } else if (diffInHours >= 5) {
        feedback = "You're getting some rest, but try to aim for 7+ hours for better health.";
    } else {
        feedback = "You need more sleep for optimal health. Try to get 7-9 hours.";
    }

    // Display the results
    document.getElementById('sleep-duration').textContent = `You slept for: ${sleepDuration}`;
    document.getElementById('feedback').textContent = feedback;

    // Show the results section
    document.getElementById('results').style.display = 'block';
});
